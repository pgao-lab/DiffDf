from common_path import *
'''Things that we can change'''
###################################################
siam_model_ = 'siamrpn_r50_l234_dwxcorr'
# siam_model_ = 'siamrpn_r50_l234_dwxcorr_otb'
###################################################
# dataset_name_ = 'OTB100'
dataset_name_ = 'VOT2018'
# dataset_name_ = 'LaSOT'
###################################################
video_name_ = ''
#########################################################################################

